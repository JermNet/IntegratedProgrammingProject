public void main(String[] args){

    new ChessGameGUI();



    //new EmptyBoard();

}
