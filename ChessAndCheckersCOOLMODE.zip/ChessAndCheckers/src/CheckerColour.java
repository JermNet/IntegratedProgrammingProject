public enum CheckerColour {
    RED, BLACK
}
